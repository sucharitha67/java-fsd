package practiseproject;

public class accessmodifier {
    private int privateVar; // private variable
    int defaultVar; // default variable
    protected int protectedVar; // protected variable
    public int publicVar; // public variable
    
    // private method
    private void privateMethod() {
        System.out.println("This is a private method.");
    }
    
    // default method
    void defaultMethod() {
        System.out.println("This is a default method.");
    }
    
    // protected method
    protected void protectedMethod() {
        System.out.println("This is a protected method.");
    }
    
    // public method
    public void publicMethod() {
        System.out.println("This is a public method.");
    }
    
    public static void main(String[] args) {
        accessmodifier obj = new accessmodifier();
        
        // Accessing private members within the same class
        obj.privateVar = 10;
        obj.privateMethod();
        
        // Accessing default members within the same package
        obj.defaultVar = 20;
        obj.defaultMethod();
        
        // Accessing protected members within the same package or subclass
        obj.protectedVar = 30;
        obj.protectedMethod();
        
        // Accessing public members from anywhere
        obj.publicVar = 40;
        obj.publicMethod();
    }
}
