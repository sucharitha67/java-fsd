package practiseproject;

import java.util.*;
public class maps {
public static void main(String[] args) {
// TODO Auto-generated method stub
// map
 //Hashmap
 HashMap<String, String> capitalCities =
new HashMap<String, String>();
 // Add keys and values (Country, City)
 capitalCities.put("England", "London");
 capitalCities.put("Germany", "Berlin");
 capitalCities.put("Norway", "Oslo");
 capitalCities.put("USA", "Washington DC");
 // capitalCities.get("England");
 //capitalCities.clear();
 System.out.println(capitalCities);
 //HashTable
 Hashtable<Integer,String> hm=new
Hashtable<Integer,String>(); 
 System.out.println("\n");
 hm.put(1,"Amit"); 
 hm.put(2,"Ravi"); 
 hm.put(3,"Vijay"); 
 hm.put(4,"Rahul"); 
 for(Map.Entry m:hm.entrySet()){ 
 System.out.println(m.getKey()+" "+m.getValue()); 
 } 
 //TreeMap
 Map<String, Integer> treeMap = new
TreeMap<>();
 System.out.println("\n");
 treeMap.put("A", 1);
 treeMap.put("C", 3);
 treeMap.put("B", 2);
 int valueA = treeMap.get("A");
 System.out.println("Value of A: " +
valueA);
 treeMap.remove("B");
 for (String key : treeMap.keySet()) {
 System.out.println("Key: " + key +
", Value: " + treeMap.get(key)); 
 } 
}
}

