package practiseproject;

public class innerclass {
    private int outerVar;
    
    public innerclass(int outerVar) {
        this.outerVar = outerVar;
    }
    
    public void outerMethod() {
        System.out.println("Outer method called");
    }
    
    public class InnerClass {
        private int innerVar;
        
        public InnerClass(int innerVar) {
            this.innerVar = innerVar;
        }
        
        public void innerMethod() {
            System.out.println("Inner method called");
        }
        
        public void accessOuterVar() {
            System.out.println("Accessing outer variable: " + outerVar);
        }
    }
    
    public static void main(String[] args) {
        innerclass obj1 = new innerclass(10);
        innerclass.InnerClass obj2 = obj1.new InnerClass(20);
        obj1.outerMethod();
        obj2.innerMethod();
        obj2.accessOuterVar();
    }
}
