package practiseproject;
public class string {
    public static void main(String[] args) {
        // Creating a String object
        String str = "Hello, world!";
        
        // Converting the String to StringBuffer
        StringBuffer buffer = new StringBuffer(str);
        buffer.reverse();
        System.out.println("StringBuffer: " + buffer);
        
        // Converting the String to StringBuilder
        StringBuilder builder = new StringBuilder(str);
        builder.reverse();
        System.out.println("StringBuilder: " + builder);
    }
}


