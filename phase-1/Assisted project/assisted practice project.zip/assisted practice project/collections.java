package practiseproject;


import java.util.*;
public class collections {
public static void main(String[] args) {
// TODO Auto-generated method stub
 //creating arraylist
System.out.println("ArrayList");
ArrayList<String> car=new ArrayList<String>(); 
 car.add("BMW");
 car.add("Audi"); 
 System.out.println(car); 
 //creating linkedlist
 System.out.println("\nLinkedList");
 LinkedList<String> cars = new
LinkedList<String>();
 cars.add("BMW");
 cars.add("Audi");
 System.out.println(cars); 
 
 //creating hashset
 System.out.println("\n");
 System.out.println("HashSet");
 HashSet<Integer> set=new HashSet<Integer>(); 
 set.add(10); 
 set.add(20); 
 set.add(30);
 set.add(40);
 System.out.println(set);
 
 //creating linkedhashset
 System.out.println("\n");
 System.out.println("LinkedHashSet");
 LinkedHashSet<Integer> set2=new
LinkedHashSet<Integer>(); 
 set2.add(1); 
 set2.add(2); 
 set2.add(3);
 set2.add(4); 
 set2.add(5); 
 set2.add(6); 
 set2.add(7);
 set2.add(8);
 System.out.println(set2);
 
 //creating vector
 System.out.println("\n");
 System.out.println("Vector");
 Vector<Integer> vec = new Vector();
 vec.addElement(15);
 vec.addElement(30);
 System.out.println(vec);
 }
}

